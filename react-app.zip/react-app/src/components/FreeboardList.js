import React from 'react';

class FreeboardList extends React.component{
    render(){
        return(
            <TopTitle />

        );
    }

}

export default FreeboardList;