import React from 'react';

class SideMenu extends React.Component{
    
}