import React from 'react';

class Apply extends React.Component{
    render(){
        return(
            asdf
        );
    }
}

export default Apply;