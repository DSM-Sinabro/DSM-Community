import Main from './Main';
import PostList from './PostList';
import QnA from './QnA';

export {Main, PostList, QnA};